﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumTestDemo1
{
    class Demo
    {
        IWebDriver driver;
        [SetUp]
        public void StartBrowser()
        {
            driver = new ChromeDriver();

        }
        [Test]
        [Order(1)]
        public void TestCase1()
        {
            driver.Navigate().GoToUrl("https://www.google.com");
            Thread.Sleep(2000);
            //or
            //driver.Url = "https://www.google.com";
            IWebElement searchTxt = driver.FindElement(By.Name("q"));
            searchTxt.SendKeys("C# Tutorial");

            //to press enter key use Keys.Enter or Keys.Return
            searchTxt.SendKeys(Keys.Enter);
            Thread.Sleep(2000);
            //IWebElement searchBtn = driver.FindElement(By.Name("btnK"));
            //Thread.Sleep(2000);
            //searchBtn.Click();
            Thread.Sleep(2000);
         
            Console.WriteLine("Test Case Ended");
        }

        [Test]
        [Order(2)]
        public void LinkTextTestCase()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://www.calculator.net");
            Thread.Sleep(2000);
            driver.Manage().Window.Maximize();
            Console.WriteLine("Test Case Started");
            //driver.FindElement(By.LinkText("Loan Calculator")).Click();
            driver.FindElement(By.PartialLinkText("Loan")).Click();
            Thread.Sleep(2000);
            

        }
        [Test]
        public void TestCase2()
        {
            driver = new ChromeDriver();
            driver.Url = "file:///C:/Swati/2021/CEP/2.%20Feb-2021/Selenium%20with%20C%23/SeleniumTestDemo1/SeleniumTestDemo1/page.html";
            Thread.Sleep(1000);
            IWebElement parent = driver.FindElement(By.TagName("div"));
            IWebElement radio1 = parent.FindElement(By.Id("r1"));
            radio1.Click();
        }

        [Test]
        public void TestCase3()
        {
            driver = new ChromeDriver();
            driver.Url = "file:///C:/Swati/2021/CEP/2.%20Feb-2021/Selenium%20with%20C%23/SeleniumTestDemo1/SeleniumTestDemo1/page.html";
            driver.Manage().Window.Maximize();
            Thread.Sleep(1000);
            IList<IWebElement> rbs = driver.FindElements(By.Name("gender"));
            rbs.ElementAt(0).Click();
            bool result = false;
            result = rbs.ElementAt(0).Selected;
            if(result==true)
            {
                rbs.ElementAt(1).Click();
                Console.WriteLine(rbs.ElementAt(1).GetAttribute("value"));
            }
            else
            {
                rbs.ElementAt(0).Click();
            }
            Thread.Sleep(1000);
        }
        [Test]
        public void DropDownExample()
        {
            driver = new ChromeDriver();
            driver.Url = "file:///C:/Swati/2021/CEP/2.%20Feb-2021/Selenium%20with%20C%23/SeleniumTestDemo1/SeleniumTestDemo1/page.html";
            IWebElement ddYear = driver.FindElement(By.Id("year"));
            SelectElement oSelect = new SelectElement(ddYear);
            oSelect.SelectByText("2012");
            Thread.Sleep(1000);
            Console.WriteLine(oSelect.SelectedOption.Text);
            oSelect.SelectByIndex(1);
            Thread.Sleep(1000);
            Console.WriteLine(oSelect.SelectedOption.Text);
            Thread.Sleep(1000);
            oSelect.DeselectByIndex(1);

            IList<IWebElement> options = oSelect.Options;

            int size = options.Count;

            for(int i=0;i<size;i++)
            {
                Console.WriteLine(oSelect.Options.ElementAt(i).Text);
                oSelect.SelectByIndex(i);
                Thread.Sleep(1000);
            }
            oSelect.DeselectAll();

        }
        [Test]
        public void CssSelectorExample()
        {
            driver = new ChromeDriver();
            driver.Url = "http://demo.guru99.com/test/login.html";

            driver.Manage().Window.Maximize();
            Thread.Sleep(1000);
            driver.FindElement(By.CssSelector("#email")).SendKeys("swati1.bhirud@gmail.com");
            Thread.Sleep(2000);
            driver.FindElement(By.CssSelector("#passwd")).SendKeys("Swati@123");
            Thread.Sleep(2000);
            driver.FindElement(By.CssSelector("#SubmitLogin")).Click();
            Thread.Sleep(2000);

        }
        [Test]
        public  void WebTableExample()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();

            driver.Url = "https://en.wikipedia.org/wiki/Programming_languages_used_in_most_popular_websites";
            IWebElement table = driver.FindElement(By.XPath("//*[@id='mw - content - text']/div[1]/table[1]"));
            List<IWebElement> rows = new List<IWebElement>(table.FindElements(By.TagName("tr")));

            string rowData = "";

            foreach(var row in rows)
            {
                List<IWebElement> cData = new List<IWebElement>(row.FindElements(By.TagName("td")));
               
                foreach(var element in cData)
                {
                    rowData = element.Text + "\t\t";
                }
                Console.WriteLine(rowData);
            }
        }
        [Test]
        public void HandleAlerts()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://demo.guru99.com/test/delete_customer.php");
            driver.FindElement(By.Name("cusid")).SendKeys("34566");
            driver.FindElement(By.Name("submit")).Submit();
            Thread.Sleep(3000);
            IAlert alert = driver.SwitchTo().Alert();
            Console.WriteLine(alert.Text);
            Thread.Sleep(3000);
            alert.Accept();
            //alert.Dismiss(); to reject the alert

        }
        [Test]
        public void HandleMultipleWindows()
        {
            driver = new ChromeDriver();
            driver.Url = "https://demoqa.com/browser-windows";
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);

            string parentWindowHandle = driver.CurrentWindowHandle;
            Console.WriteLine("Parent Window Handle:", parentWindowHandle);
            IWebElement e = driver.FindElement(By.Id("windowButton"));

            for(int i=0;i<3;i++)
            {
                e.Click();
                Thread.Sleep(2000);
            }

            List<string> allWindowHandles = driver.WindowHandles.ToList();
            foreach(var handle in allWindowHandles)
            {
                Console.WriteLine(handle);
                Console.WriteLine("Navigated to Google.com");
                driver.SwitchTo().Window(handle);
                //Thread.Sleep(2000);
                driver.Navigate().GoToUrl("https://google.com");
                //Thread.Sleep(2000);
            }
            driver.SwitchTo().Window(parentWindowHandle);
            Console.WriteLine(driver.CurrentWindowHandle);

        }

        public void WebDriverWaitExample()
        {
            driver = new ChromeDriver();
            driver.Url = "https://demoqa.com/browser-windows";
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.PollingInterval = TimeSpan.FromMilliseconds(250);
            Func<IWebDriver, bool> waitForElement = new Func<IWebDriver, bool>((IWebDriver web) =>
            {
                Console.WriteLine(web.FindElement(By.Id("windowButton")).GetAttribute("InnerHTML"));
                return true;
            });
            wait.Until(waitForElement);
            
        }
        public void DefaultWaitExample()
        {
            driver = new ChromeDriver();
            driver.Url = "https://demoqa.com/browser-windows";
            IWebElement element = driver.FindElement(By.Id("windowButon"));

            DefaultWait<IWebElement> wait = new DefaultWait<IWebElement>(element);
            wait.Timeout = TimeSpan.FromSeconds(30);
            wait.PollingInterval = TimeSpan.FromMilliseconds(250);
            Func<IWebElement, bool> waitForElement = new Func<IWebElement, bool>((IWebElement web) =>
            {
                Console.WriteLine(web.FindElement(By.Id("windowButton")).GetAttribute("InnerHTML"));
                return true;
            });
            wait.Until(waitForElement);
        }
        [TearDown]
        public void CloseBrowser()
        {
            //driver.Close();//just closes the current active browser window
            driver.Quit();//closes all the browser windows opened through webdriver
        }
    }
}
