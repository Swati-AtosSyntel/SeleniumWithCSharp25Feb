﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;

namespace SeleniumTestDemo1
{
    class Program
    {
        
        public static void SearchTestCase()

        {
            IWebDriver driver = new ChromeDriver();
            Console.WriteLine("Test Case Started");
            //to navigate to a webpage
            driver.Navigate().GoToUrl("https://www.google.com");
            Thread.Sleep(2000);
            //or
            //driver.Url = "https://www.google.com";
            IWebElement searchTxt = driver.FindElement(By.Name("q"));
            searchTxt.SendKeys("C# Tutorial");
           
            //to press enter key use Keys.Enter or Keys.Return
            searchTxt.SendKeys(Keys.Enter);
            Thread.Sleep(2000);
            //IWebElement searchBtn = driver.FindElement(By.Name("btnK"));
            //Thread.Sleep(2000);
            //searchBtn.Click();
            Thread.Sleep(2000);
            driver.Close();
            Console.WriteLine("Test Case Ended");
            Console.ReadLine();
        }
        public static void Back_ForwardCommand()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://calculator.net");
            driver.Manage().Window.Maximize();
            Console.WriteLine("Current Url:"+driver.Url);
            Thread.Sleep(1000);
            driver.Navigate().GoToUrl("https://www.google.com");
            driver.Manage().Window.Maximize();
            Console.WriteLine("Current Url:"+driver.Url);
            driver.Navigate().Back();
            Console.WriteLine("Current Url after calling back():"+driver.Url);
            driver.Navigate().Forward();
            Console.WriteLine("Current Url after calling forward():"+driver.Url);


        }

        static void Main(string[] args)
        {

            //SearchTestCase();
            Back_ForwardCommand();
        }
    }
}
