﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumTestDemo1
{
    class Demo
    {
        IWebDriver driver;
        [SetUp]
        public void StartBrowser()
        {
            driver = new ChromeDriver();

        }
        [Test]
        public void TestCase1()
        {
            driver.Navigate().GoToUrl("https://www.google.com");
            Thread.Sleep(2000);
            //or
            //driver.Url = "https://www.google.com";
            IWebElement searchTxt = driver.FindElement(By.Name("q"));
            searchTxt.SendKeys("C# Tutorial");

            //to press enter key use Keys.Enter or Keys.Return
            searchTxt.SendKeys(Keys.Enter);
            Thread.Sleep(2000);
            //IWebElement searchBtn = driver.FindElement(By.Name("btnK"));
            //Thread.Sleep(2000);
            //searchBtn.Click();
            Thread.Sleep(2000);
         
            Console.WriteLine("Test Case Ended");
        }

        [TearDown]
        public void CloseBrowser()
        {
            driver.Close();
        }
    }
}
