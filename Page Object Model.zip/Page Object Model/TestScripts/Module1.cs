﻿using NUnit.Framework;
using PageObjectModelDemo.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PageObjectModelDemo.TestScripts
{
    public class Module1:BaseTest
    {
        [Test]
        public void TestMethod1()
        {
            var searchpage = new SearchPage(driver);
            var resultPage=searchpage.NavigateToResult();
            Thread.Sleep(2000);
            resultPage.NavigateToChannel();
            Thread.Sleep(2000);
            var chanelpage = resultPage.NavigateToChannel();

            string actualChannelName = chanelpage.getChannelName();
            Console.WriteLine(actualChannelName);
            string expectedChannelName = "title";

            Assert.IsTrue(actualChannelName.Equals(expectedChannelName));

        }
    }
}
